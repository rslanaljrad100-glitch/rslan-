import os, csv, io, sqlite3, logging
from datetime import datetime
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import Application, CommandHandler, MessageHandler, ConversationHandler, ContextTypes, filters

logging.basicConfig(level=logging.INFO)
TOKEN = os.getenv('TELEGRAM_BOT_TOKEN', '').strip()
DB_PATH = os.getenv('DB_PATH', 'accounting.db')
MENU = ReplyKeyboardMarkup([
 [KeyboardButton('➕ تسجيل إيراد'), KeyboardButton('➖ تسجيل مصروف')],
 [KeyboardButton('💰 الرصيد'), KeyboardButton('📊 تقرير الشهر')],
 [KeyboardButton('🧾 آخر العمليات'), KeyboardButton('📤 تصدير CSV')],
 [KeyboardButton('❓ المساعدة')]], resize_keyboard=True)
AMOUNT, NOTE = range(2)

def db():
 c=sqlite3.connect(DB_PATH)
 c.execute('CREATE TABLE IF NOT EXISTS transactions (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, kind TEXT NOT NULL, amount REAL NOT NULL, note TEXT DEFAULT "", created_at TEXT NOT NULL)')
 c.execute('CREATE INDEX IF NOT EXISTS idx_user_date ON transactions(user_id, created_at)')
 c.commit(); return c

def totals(uid, since=None):
 out={'income':0.0,'expense':0.0}; c=db()
 q='SELECT kind, SUM(amount) FROM transactions WHERE user_id=?'; p=[uid]
 if since: q+=' AND created_at>=?'; p.append(since)
 q+=' GROUP BY kind'
 for k,v in c.execute(q,p): out[k]=v or 0.0
 c.close(); return out

def fmt(n): return f'{n:,.2f}'
async def start(u,c):
 c.user_data.clear(); await u.message.reply_text('أهلًا بك في بوت المحاسب 📒\nسجّل الإيرادات والمصروفات وتابع رصيدك وتقاريرك من الأزرار أدناه.', reply_markup=MENU)
async def help_cmd(u,c):
 await u.message.reply_text('طريقة الاستخدام:\n1) اختر تسجيل إيراد أو مصروف.\n2) أدخل المبلغ ثم وصف العملية أو - دون وصف.\n3) استخدم الرصيد والتقرير الشهري وآخر العمليات.\n4) يمكنك تصدير بياناتك إلى CSV.\n\nلا تشارك رمز البوت السري.', reply_markup=MENU)
async def begin_income(u,c): return await begin(u,c,'income')
async def begin_expense(u,c): return await begin(u,c,'expense')
async def begin(u,c,kind):
 c.user_data['kind']=kind; c.user_data.pop('amount',None)
 await u.message.reply_text('أدخل المبلغ بالأرقام فقط (مثال: 125.50).')
 return AMOUNT
async def got_amount(u,c):
 try:
  amount=float((u.message.text or '').strip().replace(',','.'))
  if amount<=0 or amount>1e12: raise ValueError
 except ValueError:
  await u.message.reply_text('المبلغ غير صحيح. أدخل رقمًا أكبر من صفر مثل 125.50.'); return AMOUNT
 c.user_data['amount']=amount; await u.message.reply_text('اكتب وصف العملية، أو أرسل - دون وصف.'); return NOTE
async def got_note(u,c):
 kind=c.user_data.get('kind'); amount=c.user_data.get('amount')
 if kind not in ('income','expense') or amount is None:
  c.user_data.clear(); await u.message.reply_text('انتهت العملية. ابدأ من القائمة.',reply_markup=MENU); return ConversationHandler.END
 note=(u.message.text or '').strip(); note='' if note=='-' else note[:250]
 con=db(); con.execute('INSERT INTO transactions(user_id,kind,amount,note,created_at) VALUES(?,?,?,?,?)',(u.effective_user.id,kind,amount,note,datetime.now().astimezone().isoformat(timespec='seconds'))); con.commit(); con.close()
 t=totals(u.effective_user.id); c.user_data.clear(); label='إيراد' if kind=='income' else 'مصروف'
 await u.message.reply_text(f'✅ تم تسجيل {label}: {fmt(amount)}\nالرصيد الحالي: {fmt(t["income"]-t["expense"])}',reply_markup=MENU); return ConversationHandler.END
async def cancel(u,c):
 c.user_data.clear(); await u.message.reply_text('تم إلغاء العملية.',reply_markup=MENU); return ConversationHandler.END
async def balance(u,c):
 t=totals(u.effective_user.id); await u.message.reply_text(f'💰 ملخص الرصيد\nالإيرادات: {fmt(t["income"])}\nالمصروفات: {fmt(t["expense"])}\n━━━━━━━━━━\nالرصيد الصافي: {fmt(t["income"]-t["expense"])}',reply_markup=MENU)
async def monthly(u,c):
 now=datetime.now().astimezone(); start=now.replace(day=1,hour=0,minute=0,second=0,microsecond=0).isoformat(); t=totals(u.effective_user.id,start)
 await u.message.reply_text(f'📊 تقرير الشهر ({now:%Y-%m})\nالإيرادات: {fmt(t["income"])}\nالمصروفات: {fmt(t["expense"])}\nالصافي: {fmt(t["income"]-t["expense"])}',reply_markup=MENU)
async def recent(u,c):
 con=db(); rows=con.execute('SELECT kind,amount,note,created_at FROM transactions WHERE user_id=? ORDER BY id DESC LIMIT 10',(u.effective_user.id,)).fetchall(); con.close()
 if not rows: await u.message.reply_text('لا توجد عمليات مسجلة حتى الآن.',reply_markup=MENU); return
 lines=['🧾 آخر العمليات:']
 for k,a,n,d in rows:
  label='➕ إيراد' if k=='income' else '➖ مصروف'; desc=f' — {n}' if n else ''; lines.append(f'{label}: {fmt(a)}{desc}\n   {d[:16]}')
 await u.message.reply_text('\n'.join(lines),reply_markup=MENU)
async def export_csv(u,c):
 con=db(); rows=con.execute('SELECT created_at,kind,amount,note FROM transactions WHERE user_id=? ORDER BY id',(u.effective_user.id,)).fetchall(); con.close()
 if not rows: await u.message.reply_text('لا توجد عمليات لتصديرها.',reply_markup=MENU); return
 out=io.StringIO(); w=csv.writer(out); w.writerow(['التاريخ','النوع','المبلغ','الوصف'])
 for d,k,a,n in rows: w.writerow([d,'إيراد' if k=='income' else 'مصروف',a,n])
 f=io.BytesIO(('\ufeff'+out.getvalue()).encode('utf-8')); f.name='accounting_report.csv'
 await u.message.reply_document(document=f,caption='📤 تقرير عملياتك بصيغة CSV.',reply_markup=MENU)
async def route(u,c):
 text=(u.message.text or '').strip()
 if text=='💰 الرصيد': return await balance(u,c)
 if text=='📊 تقرير الشهر': return await monthly(u,c)
 if text=='🧾 آخر العمليات': return await recent(u,c)
 if text=='📤 تصدير CSV': return await export_csv(u,c)
 if text=='❓ المساعدة': return await help_cmd(u,c)
 await u.message.reply_text('اختر أمرًا من الأزرار أو أرسل /help.',reply_markup=MENU)
def main():
 if not TOKEN: raise RuntimeError('Set TELEGRAM_BOT_TOKEN environment variable')
 db().close(); app=Application.builder().token(TOKEN).build()
 conv=ConversationHandler(entry_points=[MessageHandler(filters.Regex('^➕ تسجيل إيراد$'),begin_income),MessageHandler(filters.Regex('^➖ تسجيل مصروف$'),begin_expense)],states={AMOUNT:[MessageHandler(filters.TEXT & ~filters.COMMAND,got_amount)],NOTE:[MessageHandler(filters.TEXT & ~filters.COMMAND,got_note)]},fallbacks=[CommandHandler('cancel',cancel)],allow_reentry=True)
 app.add_handler(CommandHandler('start',start)); app.add_handler(CommandHandler('help',help_cmd)); app.add_handler(conv); app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND,route)); app.run_polling()
if __name__=='__main__': main()
